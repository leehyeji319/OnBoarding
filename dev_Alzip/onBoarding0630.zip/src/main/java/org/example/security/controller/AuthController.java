package org.example.security.controller;

import org.example.security.dto.TokenDto;
import org.example.security.dto.UserRequestDto;
import org.example.security.dto.UserResponseDto;
import org.example.security.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
// @CrossOrigin(origins = "*", allowedHeaders = "*")
public class AuthController {
	private final AuthService authService;

	@PostMapping("/auth/signup")
	public ResponseEntity<UserResponseDto> signup(@RequestBody UserRequestDto requestDto) {
		return ResponseEntity.ok(authService.register(requestDto));
	}

	@PostMapping("/auth/login")
	public ResponseEntity<TokenDto> login(@RequestBody UserRequestDto requestDto) {
		return ResponseEntity.ok(authService.login(requestDto));
	}

	// @PostMapping("/auth/refresh")
	// public ResponseEntity<TokenDto> refresh(@RequestBody TokenIssueRequest request) {
	// 	return ResponseEntity.ok(authService.refresh(request));
	// }
}