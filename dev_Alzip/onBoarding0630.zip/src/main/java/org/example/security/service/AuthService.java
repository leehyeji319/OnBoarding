package org.example.security.service;

import org.example.db.entity.User;
import org.example.db.repository.UserRepository;
import org.example.security.TokenProvider;
import org.example.security.dto.TokenDto;
import org.example.security.dto.UserRequestDto;
import org.example.security.dto.UserResponseDto;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class AuthService {
	private final AuthenticationManagerBuilder managerBuilder;
	private final UserRepository userRepository;
	private final PasswordEncoder passwordEncoder;
	private final TokenProvider tokenProvider;

	@Transactional
	public UserResponseDto register(UserRequestDto requestDto) {
		if (userRepository.existsByEmail(requestDto.getEmail())) {
			throw new RuntimeException("이미 가입되어 있는 유저입니다");
		}

		User user = requestDto.toEntityUser(passwordEncoder);
		return UserResponseDto.of(userRepository.save(user));
	}

	@Transactional
	public TokenDto login(UserRequestDto requestDto) {
		UsernamePasswordAuthenticationToken authenticationToken = requestDto.toAuthentication();

		Authentication authentication = managerBuilder.getObject().authenticate(authenticationToken);
		User user = userRepository.findByEmail(requestDto.getEmail()).get();
		return tokenProvider.generateTokenDto(authentication, requestDto, user);
	}

}