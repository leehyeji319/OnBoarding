package org.example.db.repository;

import org.example.db.entity.BannerFileInfo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BannerFileInfoRepository extends JpaRepository<BannerFileInfo, Long> {
}
