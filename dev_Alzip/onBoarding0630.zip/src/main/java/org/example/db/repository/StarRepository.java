package org.example.db.repository;

import java.util.List;
import java.util.Optional;

import org.example.db.entity.Star;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StarRepository extends JpaRepository<Star, Long> {

	Optional<Star> findStarByUserIdAndItemId(Long userId, Long itemId);

	List<Star> findStarsByUserId(Long userId);
}
