package org.example.api.controller;

import java.util.List;

import org.example.api.controller.common.ApiResponse;
import org.example.api.dto.item.ItemModifyRequestDto;
import org.example.api.dto.item.ItemResponseDto;
import org.example.api.dto.item.ItemSaveRequestDto;
import org.example.api.dto.item.ItemSaveResponseDto;
import org.example.api.service.ItemService;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
@Slf4j
public class ItemController {

	private final ItemService itemService;

	@GetMapping("/main")
	public ApiResponse<List<ItemResponseDto>> getMainItemList(long userId) {
		return ApiResponse.success("get main item list", itemService.findMainItemList(userId));
	}

	@GetMapping("/items")
	public ApiResponse<List<ItemResponseDto>> getItemList(long userId) {
		return ApiResponse.success("get item list", itemService.findItemList(userId));
	}

	@GetMapping("/items/{itemId}")
	public ApiResponse<ItemResponseDto> getItemDetail(@PathVariable("itemId") long itemId, long userId) {
		return ApiResponse.success("get item detail", itemService.findItem(itemId, userId));
	}

	//새로 추가. 아이템을 선택하면, 해당 카테고리에 있는 연관된 아이템 리스트를 띄워준다.
	@GetMapping("/items/{itemId}/others")
	public ApiResponse<List<ItemResponseDto>> getItemListOthers(@PathVariable("itemId") long itemId, long userId) {
		return ApiResponse.success("get other item list when click item detail",
			itemService.findItemListOther(itemId, userId));
	}

	@PostMapping("/admin/items")
	public ApiResponse<ItemSaveResponseDto> addItem(@RequestBody ItemSaveRequestDto requestDto) {
		return ApiResponse.success("create item", itemService.addItem(requestDto));
	}

	@PutMapping("/admin/items/{itemId}")
	public ApiResponse<ItemResponseDto> modifyItem(@PathVariable("itemId") long itemId,
		@RequestBody ItemModifyRequestDto requestDto) {
		return ApiResponse.success("modfiy item", itemService.modifyItem(itemId, requestDto));
	}

	@DeleteMapping("/admin/items/{itemId}")
	public ApiResponse<?> removeItem(@PathVariable("itemId") long itemId) {
		return ApiResponse.success("remove item", itemService.removeItem(itemId));
	}

	@GetMapping("/items/search")
	public ApiResponse<?> getItemListWithSearchText(@RequestParam("keyword") String keyword, long userId) {
		return ApiResponse.success("search item", itemService.searchItemWithKeyword(keyword, userId));
	}

}
