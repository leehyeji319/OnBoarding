package org.example.api.service;

import org.example.db.repository.BannerFileInfoRepository;
import org.example.db.repository.CategoryRepository;
import org.example.db.repository.ItemRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class AdminService {

	private final ItemRepository itemRepository;
	private final CategoryRepository categoryRepository;
	private final BannerFileInfoRepository bannerFileInfoRepository;

}
