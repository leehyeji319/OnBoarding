package com.estgames.db.repsitory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.estgames.db.entiity.ItemFileInfo;

public interface ItemFileInfoRepository extends JpaRepository<ItemFileInfo, Long> {
}
