package com.estgames.web.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.estgames.common.annotation.CurrentUser;
import com.estgames.common.annotation.LoginCheck;
import com.estgames.common.annotation.ValidAdmin;
import com.estgames.db.entiity.User;
import com.estgames.web.dto.item.ItemResponseDto;
import com.estgames.web.dto.item.ItemSaveRequestDto;
import com.estgames.web.service.ItemService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/api/items")
@RequiredArgsConstructor
public class ItemController {

	private final ItemService itemService;

	//아이템 검색
	@LoginCheck
	@ValidAdmin
	@GetMapping("/search")
	public String searchItem(@CurrentUser User loginUser, @RequestParam("keyword") String keyword, Model model) {
		List<ItemResponseDto> responseDtoList = itemService.searchItemWithKeywordAndIsNotMain(keyword);
		model.addAttribute("itemSearchResultList", responseDtoList);

		//현재 메인 아이템들을 찾아서 보여준다.
		List<ItemResponseDto> mainItemList = itemService.findMainItemList();
		System.out.println(mainItemList.size());
		model.addAttribute("mainItemListDto", mainItemList);

		return "/admin/mainSetting";
	}

	// 아이템 메인에 추가하기
	@LoginCheck
	@ValidAdmin
	@PutMapping("/{itemId}/main")
	public String addItemToMain(@CurrentUser User loginUser, @PathVariable("itemId") long itemId, Model model) {
		log.info("메인에 추가할 아이템~~ itemId : " + itemId);
		itemService.addItemToMain(itemId);

		//현재 메인 아이템들을 찾아서 보여준다.
		List<ItemResponseDto> mainItemList = itemService.findMainItemList();
		model.addAttribute("mainItemListDto", mainItemList);

		return "/admin/mainSetting";
	}

	@LoginCheck
	@ValidAdmin
	@DeleteMapping("/{itemId}/main")
	public String removeItemToMain(@CurrentUser User loginUser, @PathVariable("itemId") long itemId, Model model) {
		log.info("메인에서 삭제할 아이템~~ itemId : " + itemId);
		itemService.removeItemToMain(itemId);

		//현재 메인 아이템들을 찾아서 보여준다.
		List<ItemResponseDto> mainItemList = itemService.findMainItemList();
		model.addAttribute("mainItemListDto", mainItemList);

		return "admin/mainSetting";
	}

	@LoginCheck
	@ValidAdmin
	@PostMapping("/admin/items")
	public String addItem(@RequestBody ItemSaveRequestDto requestDto) {
		return null;
	}

	@LoginCheck
	@ValidAdmin
	@DeleteMapping("/{itemId}")
	public String removeItem(@PathVariable("itemId") long itemId, Model model) {
		//아이템 삭제하는 서비스 호출
		// long l = itemService.removeItem(itemId);
		// log.error("삭제된 itemId : " + itemId);


		List<ItemResponseDto> itemList = itemService.findItemList();
		model.addAttribute("itemList", itemList);
		return "admin/itemSetting";
	}

}
