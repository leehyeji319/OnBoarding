package com.estgames.web.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.estgames.web.dto.category.CategoryParentsResponseDto;
import com.estgames.web.service.CategoryService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/categories")
public class CategoryController {

	private final CategoryService categoryService;


	// @LoginCheck
	@GetMapping
	public List<CategoryParentsResponseDto> getCategoryList() {
		return categoryService.findCategoryList();
	}
}
