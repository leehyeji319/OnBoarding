package org.example.api.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.example.api.dto.cash.UserCashLogDto;
import org.example.api.dto.cash.UserCashLogResponseDto;
import org.example.db.entity.User;
import org.example.db.entity.UserCash;
import org.example.db.repository.UserCashRepository;
import org.example.db.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class UserCashService {

	private final UserCashRepository userCashRepository;
	private final UserRepository userRepository;

	public int findUserCashStatus(long userId) {
		User findUser = validateExistUserById(userId);
		return findUser.getCash();
	}

	public UserCashLogResponseDto findUserCashLogList(long userId) {
		validateExistUserById(userId);
		UserCashLogResponseDto responseDto = new UserCashLogResponseDto(userId);
		List<UserCash> userCashList = userCashRepository.findUserCashByUserId(userId);
		List<UserCashLogDto> collect = userCashList.stream()
			.map(UserCashLogDto::new)
			.collect(Collectors.toList());

		responseDto.setUserCashLogList(collect);

		return responseDto;
	}

	//캐시 충전
	public UserCashLogDto addUserCash(long userId, int amount) {
		User findUser = validateExistUserById(userId);
		findUser.chargeCash(amount);

		UserCash savedUserCash = userCashRepository.save(UserCash.builder()
			.chargeDate(LocalDateTime.now())
			.chargeType("수동")
			.chargeAmount(amount)
			.chargeBeforeCash(findUser.getCash() - amount)
			.chargeAfterCash(findUser.getCash())
			.user(findUser)
			.build());

		return new UserCashLogDto(savedUserCash);
	}

	//이건 구매에서만 할수잇는거라.. 여기 없어도 될것같다.
	public Object modifyUserCash(long userId) {
		return null;
	}

	public User validateExistUserById(long userId) {
		return userRepository.findById(userId).orElseThrow(
			() -> new IllegalArgumentException("해당 id의 user가 존재하지 않습니다. userId : " + userId)
		);
	}

	public List<UserCashLogResponseDto> findAllUserCashLogList() {

		List<UserCash> all = userCashRepository.findAll();
		// all.stream()
		// 	.map()
		return null;
	}
}
