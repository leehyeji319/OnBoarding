package org.example.api.service;

import java.util.List;
import java.util.stream.Collectors;

import org.example.api.dto.user.UserModifyResponseDto;
import org.example.db.entity.User;
import org.example.db.repository.UserRepository;
import org.example.security.dto.UserResponseDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class UserService {

	private final UserRepository userRepository;

	public UserModifyResponseDto modifyUser(long userId, UserModifyResponseDto requestDto) {
		return new UserModifyResponseDto();
	}

	public long removeUser(long userId) {
		userRepository.deleteById(userId);

		return userId;
	}

	public List<UserResponseDto> findUserList() {
		List<User> list = userRepository.findAll();

		return list.stream()
			.map(UserResponseDto::new)
			.collect(Collectors.toList());
	}

	public UserResponseDto findUser(long userId) {
		User user = userRepository.findById(userId).orElseThrow(
			() -> new IllegalArgumentException("사용자의 id가 존재하지 않습니다. userId: " + userId)
		);

		return UserResponseDto.builder()
			.id(userId)
			.email(user.getEmail())
			.name(user.getName())
			.cash(user.getCash())
			.build();
	}
}
