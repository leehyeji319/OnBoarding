package org.example.api.dto.item;

import lombok.Data;

@Data
public class ItemModifyResponseDto {

}
