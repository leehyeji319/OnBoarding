package org.example.api.dto.item;

import org.example.db.entity.Category;
import org.example.db.entity.Item;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
public class ItemSaveRequestDto {

	private String itemName;
	private int itemPrice;
	private String itemDescription;
	private boolean isMain;
	private Long categoryId;
	private String itemImgUrl;

	private Category category;

	@Builder
	public ItemSaveRequestDto(String itemName, int itemPrice, String itemDescription, boolean isMain, Long categoryId,
		String itemImgUrl, Category category) {
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.itemDescription = itemDescription;
		this.isMain = isMain;
		this.categoryId = categoryId;
		this.itemImgUrl = itemImgUrl;
		this.category = category;
	}

	public Item toEntity(Category category) {
		return Item.builder()
			.itemName(this.itemName)
			.price(this.itemPrice)
			.description(this.itemDescription)
			.isMain(this.isMain)
			.category(category)
			.itemImgUrl(this.itemImgUrl)
			.build();
	}

}
