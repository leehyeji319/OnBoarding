package org.example.api.controller;

import java.util.List;

import org.example.api.controller.common.ApiResponse;
import org.example.api.dto.item.ItemModifyRequestDto;
import org.example.api.dto.item.ItemResponseDto;
import org.example.api.dto.item.ItemSaveRequestDto;
import org.example.api.dto.item.ItemSaveResponseDto;
import org.example.api.service.ItemService;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/items")
@Slf4j
public class ItemController {

	private final ItemService itemService;

	@GetMapping
	public ApiResponse<List<ItemResponseDto>> getItemList(long userId) {
		return ApiResponse.success("get item list", itemService.findItemList(userId));
	}

	@GetMapping("/{itemId}")
	public ApiResponse<ItemResponseDto> getItemDetail(@PathVariable("itemId") long itemId, long userId) {
		return ApiResponse.success("get item detail", itemService.findItem(itemId, userId));
	}

	@PostMapping
	public ApiResponse<ItemSaveResponseDto> addItem(@RequestBody ItemSaveRequestDto requestDto) {
		return ApiResponse.success("create item", itemService.addItem(requestDto));
	}

	@PutMapping("/{itemId}")
	public ApiResponse<ItemResponseDto> modifyItem(@PathVariable("itemId") long itemId,
		@RequestBody ItemModifyRequestDto requestDto) {
		return ApiResponse.success("modfiy item", itemService.modifyItem(itemId, requestDto));
	}

	@DeleteMapping("/{itemId}")
	public ApiResponse<?> removeItem(@PathVariable("itemId") long itemId) {
		return ApiResponse.success("remove item", itemService.removeItem(itemId));
	}

}
