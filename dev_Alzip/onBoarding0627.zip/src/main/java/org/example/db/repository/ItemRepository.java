package org.example.db.repository;

import java.util.Optional;

import org.example.db.entity.Item;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemRepository extends JpaRepository<Item, Long> {
	Optional<Item> findItemByItemName(String itemName);
}
