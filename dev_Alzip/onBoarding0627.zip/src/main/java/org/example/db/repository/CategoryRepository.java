package org.example.db.repository;

import java.util.Optional;

import org.example.db.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Long> {
	Optional<Category> findCategoryByCategoryName(String categoryName);
}
