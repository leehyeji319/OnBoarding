package org.example.db.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Table(name = "orders")
@Builder(toBuilder = true)
public class Orders extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "order_id", nullable = false, updatable = false)
	private long id;

	@OneToMany(mappedBy = "orders")
	@OnDelete(action = OnDeleteAction.CASCADE)
	@Builder.Default
	private List<OrderItem> orderItemList = new ArrayList<>();

	public void addOrderItem(OrderItem orderItem) {
		this.orderItemList.add(orderItem);
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id")
	@OnDelete(action = OnDeleteAction.CASCADE)
	private User user;

	@Column(name = "order_cash_amount", nullable = false)
	private int orderCashAmount;

	@Column(name = "order_cash_before", nullable = false)
	private int orderCashBefore;

	@Column(name = "order_cash_after", nullable = false)
	private int orderCashAfter;

	public Orders(User user, int orderCashAmount, int orderCashBefore, int orderCashAfter) {
		this.user = user;
		this.orderCashAmount = orderCashAmount;
		this.orderCashBefore = orderCashBefore;
		this.orderCashAfter = orderCashAfter;
	}
}
