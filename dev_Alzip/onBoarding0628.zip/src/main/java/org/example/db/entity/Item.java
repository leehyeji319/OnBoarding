package org.example.db.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "item")
@NoArgsConstructor
@Getter
public class Item {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "item_id")
	private long id;

	@Column(name = "item_name")
	private String itemName;

	@Column(name = "item_price")
	private int price;

	@Column(name = "item_description")
	private String description;

	@Column(name = "item_img_url")
	private String itemImgUrl;

	//메인 아이템인지 여부
	@Column(name = "is_main")
	private boolean isMain;

	@ManyToOne(fetch = FetchType.LAZY)
	@OnDelete(action = OnDeleteAction.CASCADE)
	@JoinColumn(name = "category_id")
	private Category category;

	@Builder(toBuilder = true)
	public Item(long id, String itemName, int price, String description, String itemImgUrl, boolean isMain,
		Category category) {
		this.id = id;
		this.itemName = itemName;
		this.price = price;
		this.description = description;
		this.itemImgUrl = itemImgUrl;
		this.isMain = isMain;
		this.category = category;
	}
}
