package org.example.api.dto.category;

import lombok.Builder;
import lombok.Data;

@Data
public class CategoryModifyRequestDto {

	private Long parentCategoryId;
	private String parentCategoryName;
	private Long categoryId;
	private String categoryName;

	@Builder
	public CategoryModifyRequestDto(Long parentCategoryId, String parentCategoryName, Long categoryId,
		String categoryName) {
		this.parentCategoryId = parentCategoryId;
		this.parentCategoryName = parentCategoryName;
		this.categoryId = categoryId;
		this.categoryName = categoryName;
	}

}
