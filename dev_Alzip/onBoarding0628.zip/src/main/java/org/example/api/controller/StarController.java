package org.example.api.controller;

import org.example.api.controller.common.ApiResponse;
import org.example.api.service.StarService;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/star")
public class StarController {

	private final StarService starService;

	@PostMapping("/users/{userId}/items/{itemId}")
	public ApiResponse<?> addStar(@PathVariable("userId") long userId, @PathVariable("itemId") long itemId) {
		return ApiResponse.success("create star", starService.addStar(userId, itemId));
	}

	@DeleteMapping("/users/{userId}/items/{itemId}")
	public ApiResponse<?> deleteStar(@PathVariable("userId") long userId, @PathVariable("itemId") long itemId) {
		return ApiResponse.success("cancle star", starService.removeStar(userId, itemId));
	}

	@GetMapping("/users/{userId}")
	public ApiResponse<?> getUserStarList(@PathVariable("userId") long userId) {
		return ApiResponse.success("get user's star list", starService.findStarListWithUserId(userId));
	}
}
