package org.example.api.service;

import java.util.List;
import java.util.stream.Collectors;

import org.example.api.dto.item.ItemResponseDto;
import org.example.api.dto.star.StarListWithUserResponseDto;
import org.example.api.dto.star.StarResponseDto;
import org.example.db.entity.Item;
import org.example.db.entity.Star;
import org.example.db.entity.User;
import org.example.db.repository.ItemRepository;
import org.example.db.repository.StarRepository;
import org.example.db.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class StarService {

	private final StarRepository starRepository;
	private final UserRepository userRepository;
	private final ItemRepository itemRepository;

	@Transactional
	public StarResponseDto addStar(long userId, long itemId) {
		User findUser = validateExistUserById(userId);
		Item findItem = validateExistItemById(itemId);
		Star saveStar = starRepository.save(Star.builder()
			.item(findItem)
			.user(findUser)
			.build());

		return new StarResponseDto(saveStar);
	}

	@Transactional
	public long removeStar(long userId, long itemId) {
		validateExistUserById(userId);
		validateExistItemById(itemId);

		Star findStar = validateExistStarByUserIdAndItemId(userId, itemId);
		starRepository.deleteById(findStar.getId());

		return findStar.getId();
	}

	public StarListWithUserResponseDto findStarListWithUserId(long userId) {
		validateExistUserById(userId);

		StarListWithUserResponseDto responseDto = new StarListWithUserResponseDto(userId);

		List<Star> starsByUserId = starRepository.findStarsByUserId(userId);

		List<Item> itemList = toItems(starsByUserId);

		List<ItemResponseDto> collect = itemList.stream()
			.map(ItemResponseDto::new)
			.collect(Collectors.toList());

		responseDto.setUserStarItemList(collect);

		return responseDto;
	}

	private List<Long> toItemIds(List<Star> result) {
		return result.stream()
			.map(i -> i.getItem().getId())
			.collect(Collectors.toList());
	}

	private List<Item> toItems(List<Star> result) {
		return result.stream()
			.map(Star::getItem)
			.collect(Collectors.toList());
	}

	public User validateExistUserById(long userId) {
		return userRepository.findById(userId).orElseThrow(
			() -> new IllegalArgumentException("해당 id의 user가 존재하지 않습니다. userId : " + userId)
		);
	}

	public Item validateExistItemById(long itemId) {
		return itemRepository.findById(itemId).orElseThrow(
			() -> new IllegalArgumentException("해당 id의 item이 존재하지 않습니다. itemId : " + itemId)
		);
	}

	public Star validateExistStarByUserIdAndItemId(long userId, long itemId) {
		return starRepository.findStarByUserIdAndItemId(userId, itemId).orElseThrow(
			() -> new IllegalArgumentException(
				"해당 userId와 itemId에 일치하는 좋아요 정보가 존재하지 않습니다. userId : " + userId + ", itemId : " + itemId)
		);
	}
}
