package com.estgames.web.dto.item;

import lombok.Data;

@Data
public class ItemModifyResponseDto {

}
