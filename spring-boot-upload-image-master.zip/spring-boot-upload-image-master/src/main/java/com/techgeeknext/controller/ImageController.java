package com.techgeeknext.controller;

import com.techgeeknext.entities.Image;
import com.techgeeknext.repositories.ImageRepository;
import com.techgeeknext.util.ImageUtility;
import com.techgeeknext.util.MyPath;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
//@CrossOrigin(origins = "http://localhost:8082") open for specific port
@CrossOrigin() // open for all ports
public class ImageController {

    @Autowired
    ImageRepository imageRepository;

    // ================= byte 코드로 저장하는 방법 ================ //

    @PostMapping("/upload/image")
    public ResponseEntity<ImageUploadResponse> uplaodImage(@RequestParam("image") MultipartFile file)
            throws IOException {

        imageRepository.save(Image.builder()
                .name(file.getOriginalFilename())
                .type(file.getContentType())
                .image(ImageUtility.compressImage(file.getBytes())).build());
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ImageUploadResponse("Image uploaded successfully: " +
                        file.getOriginalFilename()));
    }

    @GetMapping(path = {"/get/image/info/{name}"})
    public Image getImageDetails(@PathVariable("name") String name) throws IOException {

        final Optional<Image> dbImage = imageRepository.findByName(name);

        return Image.builder()
            .id(dbImage.get().getId())
                .name(dbImage.get().getName())
                .type(dbImage.get().getType())
                .image(ImageUtility.decompressImage(dbImage.get().getImage())).build();
    }

    @GetMapping(path = {"/get/image/{name}"})
    public ResponseEntity<byte[]> getImage(@PathVariable("name") String name) throws IOException {

        final Optional<Image> dbImage = imageRepository.findByName(name);

        return ResponseEntity
                .ok()
                .contentType(MediaType.valueOf(dbImage.get().getType()))
                .body(ImageUtility.decompressImage(dbImage.get().getImage()));
    }

    @GetMapping("/get/images")
    public ResponseEntity<List<ImageResponse>> getAllImages() {
        List<Image> images = imageRepository.findAll();
        List<ImageResponse> imageResponses = new ArrayList<>();

        for (Image image : images) {
            ImageResponse imageResponse = new ImageResponse();
            imageResponse.setName(image.getName());
            imageResponse.setImage(image.getImage());  // 이미지 데이터를 가져오는 방식에 맞게 설정

            imageResponses.add(imageResponse);
        }

        return ResponseEntity.ok(imageResponses);
    }

    // ================== db에 간접적으로 저장. 파일 경로를 저장하는 방법 =============== //
    @PostMapping("/upload/db/image")
    public @ResponseBody String image(MultipartFile multipartFile) {

        UUID uuid = UUID.randomUUID();

        String imageFileName = multipartFile.getOriginalFilename();

        //사진은 하드에 저장하고, 파일 이름은 db에 저장한다.
        // String path = "D:/programming/images/upload/";

        Path imagePath = Paths.get(MyPath.IMAGE_PATH + imageFileName);

        try {
            Files.write(imagePath, multipartFile.getBytes());
        } catch (Exception e) {

        }

        return imageFileName;
    }

}