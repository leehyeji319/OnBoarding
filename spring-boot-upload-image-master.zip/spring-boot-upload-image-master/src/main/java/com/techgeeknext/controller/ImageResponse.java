package com.techgeeknext.controller;

import lombok.Data;

@Data
public class ImageResponse {

	private String name;
	private byte[] image;
}
