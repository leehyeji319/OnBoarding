package com.techgeeknext;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.resource.PathResourceResolver;

import com.techgeeknext.util.MyPath;

@Configuration
public class WebSecurityConfig implements WebMvcConfigurer {

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		WebMvcConfigurer.super.addResourceHandlers(registry);
		//외부에 있는 폴더를 내 프로젝트에서 찾을 수 있도록 세팅한다.
		registry.addResourceHandler("/upload/**")
			.addResourceLocations("file:///" + MyPath.IMAGE_PATH)
			.setCachePeriod(60*10*6)
			.resourceChain(true)
			.addResolver(new PathResourceResolver());
	}
}
