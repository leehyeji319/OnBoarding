package com.techgeeknext.util;

public class MyPath {
	public static final String IMAGE_PATH = "D:/Programming/images/upload/";
}
