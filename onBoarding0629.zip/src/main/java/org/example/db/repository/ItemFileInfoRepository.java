package org.example.db.repository;

import org.example.db.entity.ItemFileInfo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemFileInfoRepository extends JpaRepository<ItemFileInfo, Long> {
}
