package org.example.db.repository;

import java.util.List;
import java.util.Optional;

import org.example.db.entity.CartItem;
import org.example.db.entity.Item;
import org.example.db.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CartItemRepository extends JpaRepository<CartItem, Long> {

	Optional<CartItem> findByCartIdAndItemId(long cartId, long itemId);

	@Query("select ci from CartItem ci where ci.cart.user.id = :userId and ci.item.id = :itemId")
	Optional<CartItem> findByUserIdAndItemId(@Param("userId") long userId, @Param("itemId") long itemId);

	@Query("select ci from CartItem ci where ci.cart.user.id = :usreId")
	List<CartItem> findByUserId(@Param("userId") long userId);

	@Query("select ci.cart.user.id from CartItem ci where ci.id = :cartItemId")
	User findUserByCartItemId(@Param("cartItemId") long cartItemId);

	@Query("select ci.item.id from CartItem ci where ci.id = :cartItemId")
	Item findItemByCartItemId(@Param("cartItemId") long cartItemId);
}
