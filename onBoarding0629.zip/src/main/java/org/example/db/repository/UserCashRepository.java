package org.example.db.repository;

import java.util.List;

import org.example.db.entity.UserCash;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserCashRepository extends JpaRepository<UserCash, Long> {

	List<UserCash> findUserCashByUserId(long userId);

}
