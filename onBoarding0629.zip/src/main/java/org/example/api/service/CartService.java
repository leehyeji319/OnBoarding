package org.example.api.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.example.api.dto.cart.UserCartResponseDto;
import org.example.db.entity.Cart;
import org.example.db.entity.CartItem;
import org.example.db.entity.Item;
import org.example.db.entity.User;
import org.example.db.repository.CartItemRepository;
import org.example.db.repository.CartRepository;
import org.example.db.repository.ItemRepository;
import org.example.db.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class CartService {
	private final CartRepository cartRepository;
	private final CartItemRepository cartItemRepository;
	private final UserRepository userRepository;
	private final ItemRepository itemRepository;

	public List<UserCartResponseDto> findUserCartItemList(long userId) {
		List<CartItem> userCartItemList = cartItemRepository.findByUserId(userId);

		List<UserCartResponseDto> result = new ArrayList<>();

		for (CartItem findCartItem : userCartItemList) {
			User findUser = cartItemRepository.findUserByCartItemId(findCartItem.getId());
			Item findItem = cartItemRepository.findItemByCartItemId(findCartItem.getId());
			UserCartResponseDto responseDto = new UserCartResponseDto(findCartItem, findUser, findItem);
			result.add(responseDto);
		}
		return result;
	}

	//유저가 생성될 때, 카트도 자동 생성되는걸로 해야한다. -> 회원가입을 하면 유저는 기본 cart를 한개만 가지고 있다.

	@Transactional
	public List<UserCartResponseDto> addCartItem(long userId, long itemId, Integer count) {

		if (count == null) {
			count = 1;
		}

		//이미 장바구니에 있는 물품인지 확인
		Optional<CartItem> findCartItem = cartItemRepository.findByUserIdAndItemId(userId, itemId);

		try {
			if (findCartItem.isPresent()) {
				throw new IllegalArgumentException("이미 장바구니에 존재하는 상품입니다.");
			} else {
				User findUser = validateExistUserById(userId);
				Item findItem = validateExistItemById(itemId);
				Cart findCart = validateExistCartByUserId(userId);
				CartItem savedCartItem = cartItemRepository.save(CartItem.builder()
					.cart(findCart)
					.item(findItem)
					.count(count)
					.build());
			}
		} finally {
			//user의 cart list를 반환
			return findUserCartItemList(userId);
		}

	}

	@Transactional
	public long modifyCartItem(long userId, long itemId, Integer count) {
		validateExistUserById(userId);
		validateExistItemById(itemId);
		CartItem findCartItem = validateExistCartItemByUserIdAndItemId(userId, itemId);
		CartItem savedCartItem = cartItemRepository.save(findCartItem.toBuilder()
			.id(findCartItem.getId())
			.count(count)
			.build());

		return savedCartItem.getId();
	}

	//장바구니 내에서는 itemId를 알수가 없지 않나..?
	@Transactional
	public long removeCartItem(long userId, Integer itemId) {
		validateExistUserById(userId);
		validateExistItemById(itemId);
		CartItem findCartItem = validateExistCartItemByUserIdAndItemId(userId, itemId);
		cartItemRepository.deleteById(findCartItem.getId());
		return findCartItem.getId();
	}

	//수량을 어디에 받아올건데..
	public User validateExistUserById(long userId) {
		return userRepository.findById(userId).orElseThrow(
			() -> new IllegalArgumentException("해당 id의 user가 존재하지 않습니다. userId : " + userId)
		);
	}

	public Item validateExistItemById(long itemId) {
		return itemRepository.findById(itemId).orElseThrow(
			() -> new IllegalArgumentException("해당 id의 item이 존재하지 않습니다. itemId : " + itemId)
		);
	}

	public Cart validateExistCartByUserId(long userId) {
		return cartRepository.findCartByUserId(userId).orElseThrow(
			() -> new IllegalArgumentException("해당 userId로 찾은 Cart가 존재하지 않습니다. usreId : " + userId)
		);
	}

	public CartItem validateExistCartItemByUserIdAndItemId(long userId, long itemId) {
		return cartItemRepository.findByUserIdAndItemId(userId, itemId).orElseThrow(
			() -> new IllegalArgumentException(
				"해당 userId와 itemId로 일치하는 CartItem이 존재하지 않습니다. userId : " + userId + ", itemId : " + itemId)
		);
	}

}
