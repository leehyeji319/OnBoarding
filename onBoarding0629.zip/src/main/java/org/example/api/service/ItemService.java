package org.example.api.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.example.api.dto.item.ItemModifyRequestDto;
import org.example.api.dto.item.ItemResponseDto;
import org.example.api.dto.item.ItemSaveRequestDto;
import org.example.api.dto.item.ItemSaveResponseDto;
import org.example.db.entity.Category;
import org.example.db.entity.Item;
import org.example.db.entity.Star;
import org.example.db.repository.CategoryRepository;
import org.example.db.repository.ItemRepository;
import org.example.db.repository.StarRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class ItemService {

	private final ItemRepository itemRepository;
	private final StarRepository starRepository;
	private final CategoryRepository categoryRepository;

	// 메인 페이지에 뜰 아이템들 가져오기
	public List<ItemResponseDto> findMainItemList(long userId) {

		List<ItemResponseDto> result = new ArrayList<>();

		List<Item> mainItemList = itemRepository.findItemsByMainIsTrue();
		for (Item item : mainItemList) {
			ItemResponseDto responseDto = ItemResponseDto.builder()
				.itemId(item.getId())
				.itemName(item.getItemName())
				.itemPrice(item.getPrice())
				.isMain(true)
				.isStar(isExistStarByUserIdAndItemId(userId, item.getId()))
				.firstCategoryId(item.getCategory().getParent().getId())
				.firstCategoryName(item.getCategory().getParent().getCategoryName())
				.secondCategoryId(item.getCategory().getId())
				.secondCategoryName(item.getCategory().getCategoryName())
				.build();

			result.add(responseDto);
		}

		return result;

	}

	public List<ItemResponseDto> findItemList(long userId) {
		List<Item> list = itemRepository.findAll();

		//star 표시 해줘야함
		List<ItemResponseDto> result = list.stream()
			.map(ItemResponseDto::new)
			.collect(Collectors.toList());

		result.forEach(i -> i.setStar(
			isExistStarByUserIdAndItemId(userId, i.getItemId())
		));

		//category 표시 해줘야함
		//stream foreach 비효율적인가? 고민된다.
		// !!! 여기 리팩토링 필요. 포문을 한번에 돌면서 넣어주는게 백배 낫다 ..........
		result.forEach(i -> i.setFirstCategoryId((Long)findCategoryInfo(i.getItemId()).get(0)));
		result.forEach(i -> i.setFirstCategoryName((String)findCategoryInfo(i.getItemId()).get(1)));
		result.forEach(i -> i.setSecondCategoryId((Long)findCategoryInfo(i.getItemId()).get(2)));
		result.forEach(i -> i.setSecondCategoryName((String)findCategoryInfo(i.getItemId()).get(3)));

		return result;
	}

	public List<?> findCategoryInfo(long itemId) {

		List<Object> categoryInfos = new ArrayList<>();

		Item findItem = validateExistItemById(itemId);

		categoryInfos.add(findItem.getCategory().getParent().getId());
		categoryInfos.add(findItem.getCategory().getParent().getCategoryName());
		categoryInfos.add(findItem.getCategory().getId());
		categoryInfos.add(findItem.getCategory().getCategoryName());

		return categoryInfos;
	}

	public boolean isExistStarByUserIdAndItemId(Long userId, Long itemId) {
		Optional<Star> star = starRepository.findStarByUserIdAndItemId(userId, itemId);
		return star.isPresent();
	}

	public List<Long> toItemIds(List<ItemResponseDto> result) {
		return result.stream()
			.map(ItemResponseDto::getItemId)
			.collect(Collectors.toList());
	}

	//카테고리 추가해야함
	public ItemResponseDto findItem(long itemId, long userId) {
		Item findItem = validateExistItemById(itemId);

		Optional<Star> star = starRepository.findStarByUserIdAndItemId(userId, itemId);
		if (star.isEmpty()) {
			return ItemResponseDto.builder()
				.itemId(itemId)
				.itemName(findItem.getItemName())
				.itemPrice(findItem.getPrice())
				.isMain(findItem.isMain())
				.isStar(false)
				.build();
		} else {
			return ItemResponseDto.builder()
				.itemId(itemId)
				.itemName(findItem.getItemName())
				.itemPrice(findItem.getPrice())
				.isMain(findItem.isMain())
				.isStar(true)
				.build();
		}
	}

	@Transactional
	public ItemSaveResponseDto addItem(ItemSaveRequestDto requestDto) {
		//중복되는 아이템 이름 검증
		validateDuplicateItemName(requestDto.getItemName());

		Category findCategory = categoryRepository.findById(requestDto.getCategoryId()).orElseThrow(
			() -> new IllegalArgumentException(
				"해당 아이템을 넣을 카테고리 id가 존재하지 않습니다. categoryId : " + requestDto.getCategoryId())
		);

		//카테고리도 같이 받아와야함
		Item savedItem = itemRepository.save(Item.builder()
			.itemName(requestDto.getItemName())
			.price(requestDto.getItemPrice())
			.description(requestDto.getItemDescription())
			.isMain(requestDto.isMain())
			.itemImgUrl(requestDto.getItemImgUrl())
			.category(findCategory)
			.build());

		return new ItemSaveResponseDto(savedItem);
	}

	@Transactional
	public ItemResponseDto modifyItem(long itemId, ItemModifyRequestDto requestDto) {
		Item findItem = validateExistItemById(itemId);

		if (requestDto.getCategoryId() != null) {
			Category findCategory = categoryRepository.findById(requestDto.getCategoryId()).orElseThrow(
				() -> new IllegalArgumentException(
					"해당 id의 category가 존재하지 않습니다. categoryId : " + requestDto.getCategoryId())
			);

			Item modifiedItem = findItem.toBuilder()
				.id(findItem.getId())
				.itemName(requestDto.getItemName())
				.price(requestDto.getItemPrice())
				.description(requestDto.getItemDescription())
				.isMain(requestDto.isMain())
				.itemImgUrl(requestDto.getItemImgUrl())
				.category(findCategory)
				.build();

			return new ItemResponseDto(modifiedItem);
		} else {
			Item modifiedItem = findItem.toBuilder()
				.id(findItem.getId())
				.itemName(requestDto.getItemName())
				.price(requestDto.getItemPrice())
				.description(requestDto.getItemDescription())
				.isMain(requestDto.isMain())
				.itemImgUrl(requestDto.getItemImgUrl())
				.build();

			return new ItemResponseDto(modifiedItem);
		}

	}

	@Transactional
	public long removeItem(long itemId) {
		validateExistItemById(itemId);

		itemRepository.deleteById(itemId);

		return itemId;
	}

	private Item validateExistItemById(long itemId) {

		return itemRepository.findById(itemId).orElseThrow(
			() -> new IllegalArgumentException("해당 id의 item이 존재하지 않습니다. itemId : " + itemId)
		);
	}

	private void validateDuplicateItemName(String itemName) {
		Optional<Item> findItem = itemRepository.findItemByItemName(itemName);
		if (findItem.isPresent()) {
			throw new IllegalArgumentException("이미 동일한 이름의 아이템이 존재합니다.");
		}
	}

}
