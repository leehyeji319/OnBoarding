package org.example.api.controller;

import org.example.api.controller.common.ApiResponse;
import org.example.api.service.UserCashService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/cash")
public class UserCashController {

	private final UserCashService userCashService;

	@GetMapping("/users/{userId}")
	public ApiResponse<?> getUserCash(@PathVariable("userId") long userId) {
		return ApiResponse.success("get user cash status", userCashService.findUserCashStatus(userId));
	}

	@GetMapping("/users/{userId}/log")
	public ApiResponse<?> getUserCashLog(@PathVariable("userId") long userId) {
		return ApiResponse.success("get user cash logs", userCashService.findUserCashLogList(userId));
	}

	@PostMapping("/users/{userId}")
	public ApiResponse<?> addUserCash(@PathVariable("userId") long userId, @RequestParam(value = "amount") int amount) {
		return ApiResponse.success("charge user cash", userCashService.addUserCash(userId, amount));
	}

	@GetMapping("/usres")
	public ApiResponse<?> getAllUserCashLog() {
		return ApiResponse.success("get all user's cash log", userCashService.findAllUserCashLogList());
	}

}
