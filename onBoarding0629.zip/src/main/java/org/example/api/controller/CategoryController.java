package org.example.api.controller;

import java.util.List;

import org.example.api.controller.common.ApiResponse;
import org.example.api.dto.category.CategoryModifyRequestDto;
import org.example.api.dto.category.CategoryModifyResponseDto;
import org.example.api.dto.category.CategoryResponseDto;
import org.example.api.dto.category.CategorySaveRequestDto;
import org.example.api.service.CategoryService;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
public class CategoryController {

	private final CategoryService categoryService;

	//카테고리 전체 조회
	@GetMapping("/categories")
	public ApiResponse<List<CategoryResponseDto>> getCategoryList() {
		return ApiResponse.success("category List", categoryService.findCategoryList());
	}

	//카테고리 개별 조회
	@GetMapping("/categories/{categoryId}")
	public ApiResponse<CategoryResponseDto> getCategoryDetail(@PathVariable("categoryId") long categoryId) {
		return ApiResponse.success("category", categoryService.findCategory(categoryId));
	}

	//카테고리 생성
	@PostMapping("/admin/categories")
	public ApiResponse<CategoryResponseDto> addCategory(@RequestBody CategorySaveRequestDto requestDto) {
		return ApiResponse.success("create category", categoryService.addCategory(requestDto));
	}

	//카테고리 수정
	@PutMapping("/admin/categories/{categoryId}")
	public ApiResponse<CategoryModifyResponseDto> modifyCategory(@RequestBody CategoryModifyRequestDto requestDto) {
		return ApiResponse.success("modify category", categoryService.modifyCategory(requestDto));
	}

	//카테고리 삭제
	@DeleteMapping("/admin/categories/{categoryId}")
	public ApiResponse<?> removeCategory(@PathVariable("categoryId") long categoryId) {
		return ApiResponse.success("remove category", categoryService.removeCategory(categoryId));
	}

}
