package org.example.api.controller;

import java.util.List;

import org.example.api.controller.common.ApiResponse;
import org.example.api.dto.user.UserModifyResponseDto;
import org.example.api.dto.user.UserSummary;
import org.example.api.service.UserService;
import org.example.security.dto.UserResponseDto;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

	private final UserService userService;

	//회원 상단 써머리
	@GetMapping("/me/summary")
	public ApiResponse<UserSummary> getCurrentUser() {
		User principal = (User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserSummary userSummary = new UserSummary();
		//        UserSummary.builder()
		//                .id(principal.)
		//                .build();
		return ApiResponse.success("user summary", userSummary);
	}

	//회원 개인정보 수정
	@PutMapping("/{userId}")
	public ApiResponse<UserModifyResponseDto> modifyUser(@PathVariable("userId") long userId,
		@RequestBody UserModifyResponseDto requestDto) {

		return ApiResponse.success("modify user", userService.modifyUser(userId, requestDto));
	}

	//회원 회원 탈퇴
	@DeleteMapping("/{userId}")
	public ApiResponse<?> removeUser(@PathVariable("userId") long userId) {
		return ApiResponse.success("delete user", userService.removeUser(userId));
	}

	//회원 전체 조회
	@GetMapping
	public ApiResponse<List<UserResponseDto>> getUserList() {
		return ApiResponse.success("get user list", userService.findUserList());
	}

	//회원 상세 조회
	@GetMapping("/{userId}")
	public ApiResponse<UserResponseDto> getUserDetail(@PathVariable("userId") long userId) {
		return ApiResponse.success("get user", userService.findUser(userId));
	}
}
