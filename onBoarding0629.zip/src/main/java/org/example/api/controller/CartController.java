package org.example.api.controller;

import org.example.api.controller.common.ApiResponse;
import org.example.api.service.CartService;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/cart")
public class CartController {

	private final CartService cartService;

	//해당 유저의 장바구니 조회하기
	@GetMapping("/users/{userId}")
	public ApiResponse<?> getCartItem(@PathVariable("userId") long userId) {
		return ApiResponse.success("get user's cart", cartService.findUserCartItemList(userId));
	}

	//장바구니에 넣기
	@PostMapping("/users/{userId}/items/{itemId}/goods")
	public ApiResponse<?> addCartItem(@PathVariable("userId") long userId, @PathVariable("itemId") long itemId,
		@RequestParam(value = "count", required = false) Integer count) {
		return ApiResponse.success("add item cart", cartService.addCartItem(userId, itemId, count));
	}

	//장바구니에 있는 물건 수량 수정
	@PutMapping("/users/{userId}/items/{itemId}/goods")
	public ApiResponse<?> modifyCartItem(@PathVariable("userId") long userId, @PathVariable("itemId") long itemId,
		@RequestParam(value = "count", required = false) Integer count) {
		return ApiResponse.success("modify item cart", cartService.modifyCartItem(userId, itemId, count));
	}

	//장바구니에 있는 물건 삭제
	@DeleteMapping("/users/{userId}/items/{itemId}")
	public ApiResponse<?> removeCartItem(@PathVariable("userId") long userId, @PathVariable("itemId") Integer itemId) {
		return ApiResponse.success("remove item cart", cartService.removeCartItem(userId, itemId));
	}

}
