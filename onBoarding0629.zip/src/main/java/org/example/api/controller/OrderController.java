package org.example.api.controller;

import org.example.api.controller.common.ApiResponse;
import org.example.api.dto.order.OrderRequestDto;
import org.example.api.service.OrderService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/order")
public class OrderController {

	private final OrderService orderService;

	//회원의 구매 내역 조회
	@GetMapping("/users/{userId}")
	public ApiResponse<?> getUserOrderLogList(@PathVariable("userId") long userId) {
		return ApiResponse.success("get user's order list",
			orderService.findUserOderList(userId));
	}

	//구매 버튼 눌렀을 때 -> 장바구니에 담았을 때랑 똑같은 service를 호출한다.
	//원래 로직의 흐름 -> 장바구니 혹은 구매하기 버튼을 눌렀을 때, 카트로 담긴 후 -> 카트 리스트 목록을 호출한다..
	@PostMapping("/users/{userId}/items/{itemId}/goods")
	public ApiResponse<?> addUserCart(@PathVariable("userId") long userId, @PathVariable("itemId") long itemId,
		@RequestParam(value = "count", required = false) Integer count) {
		return ApiResponse.success("add cart for order",
			orderService.addUserCart(userId, itemId, count));
	}

	//계산하는거는 어떻게 보내줄건지? body로 받아오자..
	@PostMapping("/users/{userId}/pay")
	public ApiResponse<?> addOrderItemPayForGoods(@PathVariable("userId") long userId,
		@RequestBody OrderRequestDto requestDto) {
		orderService.addOrderItemPayForGoods(userId, requestDto);
		return ApiResponse.success("pay for goods and move item : cart -> orderitem", null);
	}

}
