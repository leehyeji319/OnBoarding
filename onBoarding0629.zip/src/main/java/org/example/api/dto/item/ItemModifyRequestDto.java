package org.example.api.dto.item;

import org.example.db.entity.Category;

import lombok.Builder;
import lombok.Data;

@Data
public class ItemModifyRequestDto {

	private String itemName;
	private int itemPrice;
	private String itemDescription;
	private boolean isMain;
	private Long categoryId;
	private String itemImgUrl;

	private Category category;

	@Builder
	public ItemModifyRequestDto(String itemName, int itemPrice, String itemDescription, boolean isMain, Long categoryId,
		String itemImgUrl, Category category) {
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.itemDescription = itemDescription;
		this.isMain = isMain;
		this.categoryId = categoryId;
		this.itemImgUrl = itemImgUrl;
		this.category = category;
	}
}
