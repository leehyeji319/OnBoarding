package org.example.api.dto.user;

import lombok.Data;

@Data
public class UserModifyResponseDto {

	private String name;
}
