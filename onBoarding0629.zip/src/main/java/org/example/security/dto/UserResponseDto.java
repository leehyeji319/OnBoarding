package org.example.security.dto;

import org.example.db.entity.User;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserResponseDto {
	private Long id;
	private String email;
	private String name;
	private int cash;

	public static UserResponseDto of(User user) {
		return UserResponseDto.builder()
			.id(user.getId())
			.email(user.getEmail())
			.name(user.getName())
			.cash(user.getCash())
			.build();
	}

	public UserResponseDto(User user) {
		this.id = id;
		this.email = email;
		this.name = name;
		this.cash = cash;
	}
}