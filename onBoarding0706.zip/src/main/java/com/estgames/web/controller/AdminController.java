package com.estgames.web.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.estgames.common.annotation.CurrentUser;
import com.estgames.common.annotation.LoginCheck;
import com.estgames.common.annotation.ValidAdmin;
import com.estgames.db.entiity.User;
import com.estgames.web.dto.item.ItemResponseDto;
import com.estgames.web.service.AdminService;
import com.estgames.web.service.CategoryService;
import com.estgames.web.service.ItemService;
import com.estgames.web.service.LoginService;
import com.estgames.web.service.UserService;

import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {

	private final AdminService adminService;
	private final LoginService loginService;
	private final ItemService itemService;
	private final CategoryService categoryService;
	private final UserService userService;



	//메인 아이템 추가 페이지
	@LoginCheck
	@ValidAdmin
	@GetMapping("/main/items")
	public String mainItem(@CurrentUser User loginUser, Model model) {

		//배너 아이템 띄워주기 -> 아직 구현 안됨

		//현재 메인 아이템들을 찾아서 보여준다.
		List<ItemResponseDto> mainItemList = itemService.findMainItemList();
		System.out.println(mainItemList.size());
		model.addAttribute("mainItemListDto", mainItemList);


		return "admin/mainSetting";
	}

	@LoginCheck
	@ValidAdmin
	@GetMapping("/main/banners")
	public String mainBanner(@CurrentUser User loginUser) {

		return "admin/bannerSetting";
	}

	@LoginCheck
	@ValidAdmin
	@GetMapping("/items")
	public String editItems(@CurrentUser User loginUser) {

		return "admin/itemSetting";
	}

	@LoginCheck
	@ValidAdmin
	@GetMapping("/categories")
	public String editCategories(@CurrentUser User loginUser) {
		return "admin/categorySetting";
	}



}
