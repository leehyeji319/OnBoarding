package com.estgames.db.repsitory;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.estgames.db.entiity.Item;

public interface ItemRepository extends JpaRepository<Item, Long> {
	Optional<Item> findItemByItemName(String itemName);

	@Query("select i from Item i where i.isMain = true")
	List<Item> findItemsByMainIsTrue();

	@Query("select i from Item i where i.itemName like %:text%")
	List<Item> findItemsByNameWithSearchText(@Param("text") String text);

	@Query("select i from Item i where i.id != :itemId and i.category.id = :childCategoryId")
	List<Item> findOtherItemsById(long itemId, long childCategoryId);
}
