package com.estgames.web.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.estgames.common.annotation.CurrentUser;
import com.estgames.common.annotation.LoginCheck;
import com.estgames.common.annotation.ValidAdmin;
import com.estgames.common.annotation.ValidUser;
import com.estgames.db.entiity.User;
import com.estgames.web.dto.category.CategoryParentsResponseDto;
import com.estgames.web.service.CategoryService;

import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserController {

	private final CategoryService categoryService;

	@LoginCheck
	@ValidUser
	@GetMapping("/home")
	public String userHome(@CurrentUser User loginUser, Model model) {
		List<CategoryParentsResponseDto> categoryList = categoryService.findCategoryList();
		model.addAttribute("categoryList", categoryList);
		model.addAttribute("user", loginUser);
		return "loginHome";
	}


	// === 즐겨찾기 === //
	@LoginCheck
	@ValidUser
	@GetMapping("/star")
	public String userStar(@CurrentUser User loginUser, Model model) {
		model.addAttribute("user", loginUser);

		return "user/star";
	}

	// === 장바구니 === //
	@LoginCheck
	@ValidUser
	@GetMapping("/cart")
	public String userCart(@CurrentUser User loginUser, Model model) {
		model.addAttribute("user", loginUser);

		return "user/cart";
	}

	// === 이용내역 === //
	@LoginCheck
	@ValidUser
	@GetMapping("/history")
	public String userHistory(@CurrentUser User loginUser, Model model) {
		model.addAttribute("user", loginUser);

		return "user/history";
	}

	// === 캐시충전 === //
	@LoginCheck
	@ValidUser
	@GetMapping("/charge")
	public String userCharge(@CurrentUser User loginUser, Model model) {
		model.addAttribute("user", loginUser);

		return "user/charge";
	}
}
