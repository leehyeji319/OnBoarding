package com.estgames.web.dto.user;

import lombok.Data;

@Data
public class UserModifyResponseDto {

	private String name;
}
