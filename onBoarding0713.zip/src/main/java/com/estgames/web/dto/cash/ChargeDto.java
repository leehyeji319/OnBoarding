package com.estgames.web.dto.cash;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ChargeDto {

	private String chargeMethodWay;
	private String chargeAmount;
}
