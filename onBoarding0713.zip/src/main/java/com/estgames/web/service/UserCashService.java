package com.estgames.web.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.estgames.web.dto.cash.ChargeDto;
import com.estgames.web.dto.cash.UserCashLogDto;
import com.estgames.web.dto.cash.UserCashLogResponseDto;
import com.estgames.db.entiity.User;
import com.estgames.db.entiity.UserCash;
import com.estgames.db.repsitory.UserCashRepository;
import com.estgames.db.repsitory.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class UserCashService {

	private final UserCashRepository userCashRepository;
	private final UserRepository userRepository;

	public int findUserCashStatus(long userId) {
		User findUser = validateExistUserById(userId);
		return findUser.getCash();
	}

	public UserCashLogResponseDto findUserCashLogList(long userId) {
		validateExistUserById(userId);
		UserCashLogResponseDto responseDto = new UserCashLogResponseDto(userId);
		List<UserCash> userCashList = userCashRepository.findUserCashByUserId(userId);
		List<UserCashLogDto> collect = userCashList.stream()
			.map(UserCashLogDto::new)
			.collect(Collectors.toList());

		responseDto.setUserCashLogList(collect);

		return responseDto;
	}

	//캐시 충전
	@Transactional
	public void addUserCash(long userId, ChargeDto chargeDto) {
		User findUser = validateExistUserById(userId);
		int amount = Integer.parseInt(chargeDto.getChargeAmount().replaceAll("[^0-9]", ""));

		findUser.chargeCash(amount);

		UserCash savedUserCash = userCashRepository.save(UserCash.builder()
			.chargeDate(LocalDateTime.now())
			.chargeType(chargeDto.getChargeMethodWay())
			.chargeAmount(amount)
			.chargeBeforeCash(findUser.getCash() - amount)
			.chargeAfterCash(findUser.getCash())
			.user(findUser)
			.build());

	}

	//이건 구매에서만 할수잇는거라.. 여기 없어도 될것같다.
	// public Object modifyUserCash(long userId) {
	// 	return null;
	// }

	public User validateExistUserById(long userId) {
		return userRepository.findById(userId).orElseThrow(
			() -> new IllegalArgumentException("해당 id의 user가 존재하지 않습니다. userId : " + userId)
		);
	}

	public List<UserCashLogResponseDto> findAllUserCashLogList() {

		List<UserCash> all = userCashRepository.findAll();
		// all.stream()
		// 	.map()
		return null;
	}
}
