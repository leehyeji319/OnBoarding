package com.estgames.web.dto.item;


import com.estgames.db.entiity.Category;
import com.estgames.db.entiity.Item;

import lombok.Builder;
import lombok.Data;

@Data
// @NoArgsConstructor
// @RequiredArgsConstructor
public class ItemSaveRequestDto {

	private String itemName;
	private int itemPrice;
	private String itemDescription;
	private boolean isMain;
	private Long categoryId;
	private String itemImgUrl;

	private Category category;

	@Builder
	public ItemSaveRequestDto(String itemName, int itemPrice, String itemDescription, boolean isMain, Long categoryId,
		String itemImgUrl, Category category) {
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.itemDescription = itemDescription;
		this.isMain = isMain;
		this.categoryId = categoryId;
		this.itemImgUrl = itemImgUrl;
		this.category = category;
	}

	public Item toEntity(Category category) {
		return Item.builder()
			.itemName(this.itemName)
			.price(this.itemPrice)
			.description(this.itemDescription)
			.isMain(this.isMain)
			.category(category)
			.itemImgUrl(this.itemImgUrl)
			.build();
	}

}
