package com.estgames.web.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.estgames.common.annotation.CurrentUser;
import com.estgames.common.annotation.LoginCheck;
import com.estgames.common.annotation.ValidAdmin;
import com.estgames.db.entiity.User;
import com.estgames.web.dto.item.ItemResponseDto;
import com.estgames.web.service.ItemService;

import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/api/items")
@RequiredArgsConstructor
public class ItemController {

	private final ItemService itemService;

	@LoginCheck
	@ValidAdmin
	@GetMapping("/search")
	public String searchItem(@CurrentUser User loginUser, @RequestParam("keyword") String keyword, Model model) {
		List<ItemResponseDto> responseDtoList = itemService.searchItemWithKeyword(keyword);
		model.addAttribute("itemSearchResultList", responseDtoList);

		//현재 메인 아이템들을 찾아서 보여준다.
		List<ItemResponseDto> mainItemList = itemService.findMainItemList();
		System.out.println(mainItemList.size());
		model.addAttribute("mainItemListDto", mainItemList);

		return "/admin/mainSetting";
	}

}
