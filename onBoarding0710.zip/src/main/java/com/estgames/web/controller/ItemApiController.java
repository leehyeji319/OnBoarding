package com.estgames.web.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.estgames.common.annotation.CurrentUser;
import com.estgames.common.annotation.LoginCheck;
import com.estgames.common.annotation.ValidAdmin;
import com.estgames.db.entiity.User;
import com.estgames.web.dto.category.CategoryParentsResponseDto;
import com.estgames.web.dto.item.ItemModifyRequestDto;
import com.estgames.web.dto.item.ItemResponseDto;
import com.estgames.web.dto.item.ItemSaveRequestDto;
import com.estgames.web.service.CategoryService;
import com.estgames.web.service.ItemService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/api/items")
@RequiredArgsConstructor
public class ItemApiController {

	private final ItemService itemService;
	private final CategoryService categoryService;

	//카테고리 별 아이템 조회
	// @LoginCheck
	// @GetMapping("/categories/{categoryId}")
	// @ResponseBody
	// public List<ItemResponseDto> getItemListWithCategoryId(@PathVariable("categoryId") long categoryId, Model model) {
	// 	//들어왔어!!!
	// 	log.error("카테고리 조회로 성공적으로 컨트롤러까지 왓어용. categoryId : " + categoryId);
	//
	// 	//카테고리 리스트
	// 	List<CategoryParentsResponseDto> categoryList = categoryService.findCategoryList();
	// 	// model.addAttribute("categoryList", categoryList);
	//
	// 	//카테고리 별로 아이템 호출
	// 	List<ItemResponseDto> itemList = itemService.findItemListWithCategoryId(categoryId);
	// 	// model.addAttribute("itemList", itemList);
	//
	// 	// return "admin/itemSetting :: #items";
	// 	return "itemList;
	// }

	@LoginCheck
	@GetMapping("/categories/{categoryId}")
	public String getItemListWithCategoryId(@PathVariable("categoryId") long categoryId, Model model) {
		log.error("카테고리 조회로 성공적으로 컨트롤러까지 왔어요. categoryId: " + categoryId);

		// 카테고리 별로 아이템 호출
		List<ItemResponseDto> itemList = itemService.findItemListWithCategoryId(categoryId);
		model.addAttribute("itemList", itemList);


		// ModelAndView modelAndView = new ModelAndView("admin/itemSetting");
		// modelAndView.addObject("itemList", itemList);

		// return modelAndView;

		return "admin/itemSetting :: #items";
	}

	//아이템 검색
	@LoginCheck
	@ValidAdmin
	@GetMapping("/search")
	public String searchItem(@CurrentUser User loginUser, @RequestParam("keyword") String keyword, Model model) {
		List<ItemResponseDto> responseDtoList = itemService.searchItemWithKeywordAndIsNotMain(keyword);
		model.addAttribute("itemSearchResultList", responseDtoList);

		//현재 메인 아이템들을 찾아서 보여준다.
		List<ItemResponseDto> mainItemList = itemService.findMainItemList();
		System.out.println(mainItemList.size());
		model.addAttribute("mainItemListDto", mainItemList);

		return "/admin/mainSetting";
	}

	// 아이템 메인에 추가하기
	@LoginCheck
	@ValidAdmin
	@PutMapping("/{itemId}/main")
	public String addItemToMain(@CurrentUser User loginUser, @PathVariable("itemId") long itemId, Model model) {
		log.info("메인에 추가할 아이템~~ itemId : " + itemId);
		itemService.addItemToMain(itemId);

		//현재 메인 아이템들을 찾아서 보여준다.
		List<ItemResponseDto> mainItemList = itemService.findMainItemList();
		model.addAttribute("mainItemListDto", mainItemList);

		return "/admin/mainSetting";
	}


	//아이템 메인에서 삭제
	@LoginCheck
	@ValidAdmin
	@DeleteMapping("/{itemId}/main")
	public String removeItemToMain(@CurrentUser User loginUser, @PathVariable("itemId") long itemId, Model model) {
		log.info("메인에서 삭제할 아이템~~ itemId : " + itemId);
		itemService.removeItemToMain(itemId);

		//현재 메인 아이템들을 찾아서 보여준다.
		List<ItemResponseDto> mainItemList = itemService.findMainItemList();
		model.addAttribute("mainItemListDto", mainItemList);

		return "admin/mainSetting";
	}


	//아이템 새로 생성 (추가)
	@LoginCheck
	@ValidAdmin
	@PostMapping
	public String addItem(@ModelAttribute ItemSaveRequestDto requestDto, Model model) {

		log.error("아이템 생성 컨틀롤러 들어왔땅께 ~~~~! : " + requestDto.toString());
		itemService.addItem(requestDto);


		//카테고리 리스트 호출 대분류 중분류(셀렉트 박스를 위해)
		List<CategoryParentsResponseDto> categoryList = categoryService.findCategoryList();
		model.addAttribute("categoryList", categoryList);

		List<ItemResponseDto> itemList = itemService.findItemList();
		model.addAttribute("itemList", itemList);

		return "admin/itemSetting";
	}


	//아이템 삭제
	@LoginCheck
	@ValidAdmin
	@DeleteMapping("/{itemId}")
	public String removeItem(@PathVariable("itemId") long itemId, Model model) {
		//아이템 삭제하는 서비스 호출
		long l = itemService.removeItem(itemId);
		log.error("삭제된 itemId : " + itemId);


		//카테고리 리스트 호출 대분류 중분류(셀렉트 박스를 위해)
		List<CategoryParentsResponseDto> categoryList = categoryService.findCategoryList();
		model.addAttribute("categoryList", categoryList);

		List<ItemResponseDto> itemList = itemService.findItemList();
		model.addAttribute("itemList", itemList);
		return "admin/itemSetting";
	}

	//아이템 수정
	@LoginCheck
	@ValidAdmin
	@PutMapping("/{itemId}")
	public String modifyItem(@PathVariable("itemId") long itemId, @ModelAttribute ItemModifyRequestDto itemModifyRequestDto, Model model) {
		log.error("아이템 수정 컨틀롤러 들어왔땅께 ~~~~! : " + itemModifyRequestDto.toString());
		itemService.modifyItem(itemId, itemModifyRequestDto);

		List<ItemResponseDto> itemList = itemService.findItemList();
		model.addAttribute("itemList", itemList);
		return "admin/itemSetting";
	}

}
