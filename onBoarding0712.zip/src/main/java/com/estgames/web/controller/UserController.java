package com.estgames.web.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.estgames.common.annotation.CurrentUser;
import com.estgames.common.annotation.LoginCheck;
import com.estgames.common.annotation.ValidAdmin;
import com.estgames.common.annotation.ValidUser;
import com.estgames.db.entiity.User;
import com.estgames.web.dto.cart.UserCartResponseDto;
import com.estgames.web.dto.category.CategoryParentsResponseDto;
import com.estgames.web.dto.item.ItemResponseDto;
import com.estgames.web.dto.star.StarListWithUserResponseDto;
import com.estgames.web.service.CartService;
import com.estgames.web.service.CategoryService;
import com.estgames.web.service.StarService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserController {

	private final CategoryService categoryService;
	private final StarService starService;
	private final CartService cartService;

	@LoginCheck
	@ValidUser
	@GetMapping("/home")
	public String userHome(@CurrentUser User loginUser, Model model) {
		List<CategoryParentsResponseDto> categoryList = categoryService.findCategoryList();
		model.addAttribute("categoryList", categoryList);
		model.addAttribute("user", loginUser);
		return "loginHome";
	}


	// === 즐겨찾기 === //
	@LoginCheck
	@ValidUser
	@GetMapping("/star")
	public String userStar(@CurrentUser User loginUser, Model model) {
		model.addAttribute("user", loginUser);

		//즐겨찾기 리스트 가져오기
		List<ItemResponseDto> starItemList = starService.findStarListWithUserId(loginUser.getId());

		model.addAttribute("starItemList", starItemList);
		return "user/star";
	}

	// === 장바구니 === //
	@LoginCheck
	@ValidUser
	@GetMapping("/cart")
	public String userCart(@CurrentUser User loginUser, Model model) {
		model.addAttribute("user", loginUser);

		//장바구니 리스트 가져오기
		List<UserCartResponseDto> cartItemList = cartService.findUserCartItemList(loginUser.getId());

		log.error("UserController에서 호출중..... cartItemList::" + cartItemList.toString());

		model.addAttribute("cartItemList", cartItemList);

		return "user/cart";
	}

	// === 이용내역 === //
	@LoginCheck
	@ValidUser
	@GetMapping("/history")
	public String userHistory(@CurrentUser User loginUser, Model model) {
		model.addAttribute("user", loginUser);

		return "user/history";
	}

	// === 캐시충전 === //
	@LoginCheck
	@ValidUser
	@GetMapping("/charge")
	public String userCharge(@CurrentUser User loginUser, Model model) {
		model.addAttribute("user", loginUser);

		return "user/charge";
	}
}
