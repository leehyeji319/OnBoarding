package com.estgames.web.dto.item;


import com.estgames.db.entiity.Item;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ItemResponseDto {

	private Long itemId;
	private String itemName;
	private int itemPrice;
	@JsonProperty("isMain")
	private boolean isMain;
	@JsonProperty("isStar")
	private boolean isStar;
	private String itemDescription;

	private Long firstCategoryId;
	private String firstCategoryName;

	private Long secondCategoryId;
	private String secondCategoryName;

	@Builder
	public ItemResponseDto(Long itemId, String itemName, int itemPrice, boolean isMain, boolean isStar,
		Long firstCategoryId, String firstCategoryName, String itemDescription,
		Long secondCategoryId, String secondCategoryName) {
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.isMain = isMain;
		this.isStar = isStar;
		this.itemDescription = itemDescription;
		this.firstCategoryId = firstCategoryId;
		this.firstCategoryName = firstCategoryName;
		this.secondCategoryId = secondCategoryId;
		this.secondCategoryName = secondCategoryName;
	}

	public ItemResponseDto(Long itemId, String itemName, int itemPrice, boolean isMain, Long firstCategoryId,
		String firstCategoryName, String itemDescription,
		Long secondCategoryId, String secondCategoryName) {
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.isMain = isMain;
		this.itemDescription = itemDescription;
		this.firstCategoryId = firstCategoryId;
		this.firstCategoryName = firstCategoryName;
		this.secondCategoryId = secondCategoryId;
		this.secondCategoryName = secondCategoryName;
	}

	public ItemResponseDto(Item item) {
		this.itemId = item.getId();
		this.itemName = item.getItemName();
		this.itemPrice = item.getPrice();
		this.isMain = item.isMain();
		this.itemDescription = item.getDescription();
		this.firstCategoryId = item.getCategory().getParent().getId();
		this.firstCategoryName = item.getCategory().getParent().getCategoryName();
		this.secondCategoryId = item.getCategory().getId();
		this.secondCategoryName = item.getCategory().getCategoryName();
	}
}
