package com.estgames.db.repsitory;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.estgames.db.entiity.Star;

public interface StarRepository extends JpaRepository<Star, Long> {

	Optional<Star> findStarByUserIdAndItemId(Long userId, Long itemId);

	List<Star> findStarsByUserId(Long userId);
}
