package com.estgames.api.controller;

public interface SessionConstants {

	//interface 혹은 abstract로 빼서 객체 생성을 막을 수 있다.
	String LOGIN_USER = "loginUser";

}
