package com.estgames.api.service;

import org.springframework.stereotype.Service;

import com.estgames.db.entiity.User;
import com.estgames.db.repsitory.UserRepository;
import com.estgames.db.repsitory.UserRepositoryImpl;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class LoginService {

	private final UserRepositoryImpl userRepositoryImpl;
	private final UserRepository userRepository;


	public User login(String loginId, String password) {

		return userRepositoryImpl.findByLoginId(loginId).filter(u -> u.getPassword().equals(password))
			.orElse(null);
		//if null then login fail
	}

}
